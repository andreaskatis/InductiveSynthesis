#ifndef _EXAMPLE
#define _EXAMPLE

#include <stdlib.h>

extern _Bool x[2];

extern int state[2];
extern _Bool prop4[2];
extern _Bool prop3[2];
extern _Bool prop2[2];
extern _Bool prop_all[2];
extern _Bool prop1[2];
extern int bias[2];
extern _Bool bias_max[2];

extern void skolem_0();

extern void skolem_1();

extern void moveHistory();

extern void updateFunction();

#endif
